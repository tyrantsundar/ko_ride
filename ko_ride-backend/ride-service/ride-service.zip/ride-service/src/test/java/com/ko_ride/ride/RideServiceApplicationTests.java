package com.ko_ride.ride;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RideServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
